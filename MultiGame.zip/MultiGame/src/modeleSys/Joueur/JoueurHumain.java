package modeleSys.Joueur;

public class JoueurHumain extends Joueur {
    public JoueurHumain(String nom){
        super(nom);
    }
}

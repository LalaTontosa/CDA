package modeleSys.exception;

public class InvalidCoup extends Exception{
    public InvalidCoup(){
        super("Coup invalide");
    }
}

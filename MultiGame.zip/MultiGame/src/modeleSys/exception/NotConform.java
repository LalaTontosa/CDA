package modeleSys.exception;

public class NotConform extends Exception {
    public NotConform(){
        super("Le damier n'est pas conforme");
    }
}

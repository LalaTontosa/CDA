package modeleSys.exception;

public class InvalidMove extends Exception{
    public  InvalidMove(){
        super("Mouvement incorrect");
    }
}

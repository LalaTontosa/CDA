package modeleSys.strategie;

import modeleSys.interfaces.JeuPlateau;
import modeleSys.interfaces.Strategie;
import modeleSys.othello.Othello;

public class Minimax implements Strategie {
    @Override
    public Object appliquer(JeuPlateau jeuPlateau){
        return null;
    }

    @Override
    public String getName() {
        return "Minimax";
    }

}
